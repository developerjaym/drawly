export default function Save() {
    return document.getElementById("canvas").toDataURL();
}