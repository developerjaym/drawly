export default class {
    static get ERASER() {
        return "ERASER";
    }
    static get DRAW() {
        return "DRAW";
    }
}