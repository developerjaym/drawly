export default class ShortCuts {
    static get UNDO() {
        return "UNDO";
    }
    static get CLEAR_ALL_STROKES() {
        return "CLEAR_ALL_STROKES";
    }
    static get DOWNLOAD() {
        return "DOWNLOAD";
    }
    static get NONE() {
        return "NONE";
    }
}